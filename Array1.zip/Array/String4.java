package Array;

public class String4 {

	public static void main(String[] args) {
		String s="javA5is&su6p%eR";
		int upper=0,lower=0,digit=0,special=0;
		char[] arr=s.toCharArray();
		for(int i=0;i<arr.length;i++) {
			if(arr[i]>='A'&&arr[i]<='Z')
				upper++;
			else if(arr[i]>='0'&&arr[i]<='9')
				digit++;
			else if(arr[i]>='a'&&arr[i]<='z')
				lower++;
			else
				special++;
				
		}
		System.out.println(upper);
		System.out.println(lower);
		System.out.println(digit);
		System.out.println(special);

	}

}
