package Spring;
public class Min{
	public static int LargestElement(int[] num) {
		int n=num.length;
		int min=num[0];
		for(int i=0;i<n;i++) {
			if(num[i]<min)
				min=num[i];
		}
		return min;
		
	}

	public static void main(String[] args) {
		int[] arr= {5,8,9,7,9,8};
		System.out.println(LargestElement(arr));

	}

}


	




