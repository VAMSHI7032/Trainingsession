package Day3;
import java.util.*;
public class Sumarray {
	public static int[] SumArray(int[] arr1,int[] arr2) {
		int[] result=new int[arr1.length];
		for(int i=0; i<arr1.length;i++) {
			result[i]=arr1[i]+arr2[i];
		}
 		
		return result;
	}

	public static void main(String[] args) {
		 int[] arr1 = {1, 2, 3};
	        int[] arr2 = {4, 5, 6};

	        System.out.println(Arrays.toString(SumArray(arr1, arr2)));

	}

}
