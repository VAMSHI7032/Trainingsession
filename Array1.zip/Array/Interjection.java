package Array;
import java.util.*;
public class Interjection {
public static int inter(int[] arr1,int[] arr2) {
	HashSet<Integer> set =new HashSet<>();
	int count=0;
	for(int i=0;i<arr1.length;i++) {
		set.add(arr1[i]);
		//System.out.println(set);
	}
	for(int j=0;j<arr2.length;j++) {
		if(set.contains(arr2[j])) {
			System.out.println(arr2[j]);
		count++;
		set.remove(arr2[j]);
		
		}
	}
	return count;
}
	public static void main(String[] args) {
	
	int[] arr1= {7,3,9};
	int[] arr2= {6,3,9,2,9,4};
	System.out.println(inter(arr1,arr2));

	}

}
