package Array;

public class String5 {

    public static String removeOccurrences(String s, String part) {
        StringBuilder sb = new StringBuilder();
        int m = part.length();

        for (char c : s.toCharArray()) {
            sb.append(c);

            if (sb.length() >= m &&
                sb.substring(sb.length() - m).equals(part)) {
                sb.delete(sb.length() - m, sb.length());
            }
        }
        return sb.toString();
    }

    public static void main(String[] args) {
        String s = "daabcbaabcbc";
        String part = "abc";

        System.out.print(removeOccurrences(s, part)); // dababa
    }
}
