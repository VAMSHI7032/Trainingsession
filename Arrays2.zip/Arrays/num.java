package Arrays;

public class num {

}
