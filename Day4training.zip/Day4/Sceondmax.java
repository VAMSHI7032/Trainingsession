package Day4;

public class Sceondmax {
	

		public static void main(String[] args) {
			int[] arr = {4,10,10,8,3,8};
			int max=Integer.MIN_VALUE;
			int smax=Integer.MIN_VALUE;
			for(int i=0;i<arr.length;i++) {
				if(arr[i]>max && arr[i]!=max)
					smax=arr[i];
			}
			System.out.println(smax);
		}

}
