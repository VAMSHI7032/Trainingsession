package Array;

public class String7 {

    public static void main(String[] args) {
        String s = "panama";
        boolean palindrome = true;

        int st = 0, end = s.length() - 1;

        while (st < end) {

            // skip non-alphanumeric from start
            while (st < end && !Character.isLetterOrDigit(s.charAt(st))) {
                st++;
            }

            // skip non-alphanumeric from end
            while (st < end && !Character.isLetterOrDigit(s.charAt(end))) {
                end--;
            }

            // compare characters
            if (Character.toLowerCase(s.charAt(st)) !=
                Character.toLowerCase(s.charAt(end))) {
                palindrome = false;
                
            }

            st++;
            end--;
        }

        if (palindrome) {
            System.out.println("It is a palindrome");
        } else {
            System.out.println("It is not a palindrome");
        }
    }
}

	   
