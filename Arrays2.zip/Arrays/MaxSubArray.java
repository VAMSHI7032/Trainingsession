package Arrays;

public class MaxSubArray {
public static int maxSub(int[] arr) {
	int currsum=0;
	
	int maxsum=Integer.MIN_VALUE;
	for(int value:arr) {
		
		currsum +=value;
		maxsum=Math.max(currsum, maxsum);
		System.out.print(currsum);
		System.out.print(maxsum);
		if(currsum<0)
			currsum=0;
	}
	
	return maxsum;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
int arr[]= {-2,-1,-3,4,-1,2,1,-5,4};
 System.out.println(maxSub(arr));
	}

}
