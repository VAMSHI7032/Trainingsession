package Spring;

import java.util.Scanner;

public class EvenOrnot {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		if(n%2==0)
			System.out.println("given no is even number"+n);
		else
			System.out.println("given no is odd number"+n);

	}

}
