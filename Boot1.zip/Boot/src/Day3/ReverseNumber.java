package Day3;

import java.util.Arrays;

public class ReverseNumber {
public static int[] reverse(int[] arr) {
	int n=arr.length-1;
	int left=0, right=n;
	while(left<right) {
		int temp=arr[left];
		arr[left]=arr[right];
		arr[right]=temp;
		left++;
		right--;
		
	}
	return arr;
}
	public static void main(String[] args) {
		int[] arr= {1,2,3,4,5};
		System.out.println(Arrays.toString(reverse(arr)));
		

	}

}
