package Arrays;

import java.util.HashMap;

public class MajorityValues {
	static int Majority(int[] arr) {
		HashMap<Integer,Integer> map=new HashMap<>();
		for( int i=0;i<arr.length;i++) {
			if(map.containsKey(arr[i])) {
				map.put(arr[i], map.get(arr[i])+1);
			}
			else {
				map.put(arr[i],1);
			}
			
		}
		for(int x:map.keySet()) {
			if(map.get(x)>arr.length/2)
				return x;
			
		}
		return -1;
	}
		
		/*int n=arr.length;
		int count=0;
		int maxsum=0;
		for(int i=0;i<n;i++) {
		if(count==0) {
			maxsum=arr[i];
		}	
		if(arr[i]==maxsum) {
			count++;
		}
		else {
			count--;
		}
		}
		System.out.println(maxsum);
		
	}*/
public static void main(String[] args) {
		int[] arr= {1,2,2,1,1};
		System.out.println(Majority(arr));
		
	}

	}


