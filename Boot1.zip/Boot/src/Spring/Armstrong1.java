package Spring;
import java.util.*;
public class Armstrong1 {
public static boolean isArmstrong(int n) {
	int original=n;
	int sum=0;
	int digits=String.valueOf(n).length();
	while(n>0) {
		int digit=n%10;
		sum+=Math.pow(digit,digits);
		n/=10;
		
	}
return sum==original;	
}
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int k=sc.nextInt();
	System.out.println(isArmstrong(k));
}
}
