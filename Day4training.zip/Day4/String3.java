package Day4;

import java.util.Arrays;

public class String3 {
	public  static boolean isAnagram(String s,String t) {
		char[] arr=s.toCharArray();
		char[] arr1=t.toCharArray();
		Arrays.sort(arr);
		Arrays.sort(arr1);
		if(Arrays.equals(arr, arr1)) {
			return true;
		}
	return false;	
	}

	public static void main(String[] args) {
		String s="abcabd";
		String t="dabcab";
		System.out.println(isAnagram(s,t));
	}

}
