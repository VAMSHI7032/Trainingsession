package Day4;

import s1;

public class String1 {
	
	public static void main(String[] args) {
	 String s="hello world";
	 System.out.println(s.length());
	
		}

	
	}


