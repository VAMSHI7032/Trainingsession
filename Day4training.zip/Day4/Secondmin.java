package Day4;

public class Secondmin {

	public static void main(String[] args) {
		int[] arr= {-1,5,-3,8,7,-9};
		int min=Integer.MAX_VALUE;
		int smin=Integer.MAX_VALUE;
		for(int i=0;i<arr.length;i++) {
			if(arr[i]<min && arr[i]!=0)
				smin=arr[i];
		}
		System.out.println(smin);
	}

}

