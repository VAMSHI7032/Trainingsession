package Arrays;
import java.util.*;
public class union {
public static int print1(int arr[],int arr1[]) {
	HashSet<Integer> set=new HashSet<>();
	for(int x:arr) {
		set.add(x);
	}
	for(int j=0;j<arr1.length;j++) {
		set.add(arr1[j]);
		System.out.println(set);
		}
	
	return set.size();
}
	public static void main(String[] args) {
		int arr[]= {7,3,9};
		int arr2[]= {6,3,9,2,9,4};
		System.out.println(print1(arr,arr2));
	}

}
