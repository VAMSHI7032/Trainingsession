package Array;

public class Smax {
	public static int secondLargest(int arr[]) {
		int n=arr.length;
		int max=Integer.MIN_VALUE;
		int smax=Integer.MIN_VALUE;
		for(int i=0;i<n;i++) {
			if(smax<arr[i]) {
				smax=max;
				max=arr[i];
			}
		}
		return max;
	}
	public static void main(String[] args) {
		int arr[] = {12 ,35, 1, 10, 34, 1};
		System.out.println(secondLargest(arr));
				
	}

}
