package Array;

import java.util.Arrays;
public class ShallowCopyDeepCopy {

	public static void main(String[] args) {
		int[] arr= {10,20,45,66,78};
		//int[] x = arr;//x is shallow of arr
		int[] deep=Arrays.copyOf(arr,arr.length);
		deep[0]=100;
		System.out.println(deep[0]);
			System.out.println(arr[0]);
			
		

	}

}
