package Arrays;
import java.util.*;

public class ThreeSum {

    public static List<List<Integer>> threeSum(int[] nums) {

        // Set to store unique triplets
        Set<List<Integer>> result = new HashSet<>();

        int n = nums.length;

        // Fix first element
        for (int i = 0; i < n; i++) {

            // HashSet for 2Sum
            Set<Integer> seen = new HashSet<>();

            for (int j = i + 1; j < n; j++) {

                int third = -(nums[i] + nums[j]);

                // Check if required number exists
                if (seen.contains(third)) {

                    List<Integer> triplet =
                            Arrays.asList(nums[i], nums[j], third);

                    // Sort to avoid duplicates
                    Collections.sort(triplet);

                    result.add(triplet);
                }

                seen.add(nums[j]);
            }
        }

        return new ArrayList<>(result);
    }

    // Main method for testing
    public static void main(String[] args) {

        int[] nums = {-1, 0, 1, 2, -1, -4};

        List<List<Integer>> ans = threeSum(nums);

        System.out.println(ans);
    }
}

	
	

	    

	


