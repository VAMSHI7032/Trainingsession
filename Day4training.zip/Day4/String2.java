package Day4;

public class String2 {
	public static void reverse(char[] c) {
		int s=0;
		int end=c.length-1;
		while(s<end) {
			char temp=c[s];
			c[s]=c[end];
			c[end]=temp;
			s++;
			end--;
		}
		
	}
public static void main(String[] args) {
		String s="hello";
		char[] ch=s.toCharArray();
		reverse(ch);
		System.out.println(new String(ch));

	}

}
