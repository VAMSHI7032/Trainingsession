package Array;
import java.util.*;
import java.util.HashMap;

class SubArraySumEqualToK {
    public static int subarraySum(int[] nums, int k) {
        HashMap<Integer, Integer> map = new HashMap<>();
        
        // Base case
        map.put(0, 1);

        int sum = 0;
        int count = 0;

        for (int num : nums) {
            sum += num;

            if (map.containsKey(sum - k)) {
                count += map.get(sum - k);
            }

            map.put(sum, map.getOrDefault(sum,0) + 1);
        }

        return count;
    }


	public static void main(String[] args) {
		int[] arr= {9,4,20,3,10,5};
		int target=33;
		System.out.println(subarraySum(arr,target));
	}

}
