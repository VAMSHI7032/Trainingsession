package Array;
import java.util.*;
public class TwoSum {
	
	public static int[] twoSum(int[] nums, int target) {
        HashMap<Integer, Integer> map = new HashMap<>();

        for (int i = 0; i < nums.length; i++) {
            int sum= target - nums[i];

            if (map.containsKey(sum)) {
                return new int[] { map.get(sum), i };
            }

            map.put(nums[i], i);
        }
        return new int[] {};
    }


	 
	    public static void main(String[] args) {
	        int[] arr = { 2, 7, 11, 15};
	        int target = 9;
	        int[] result = twoSum(arr, target);
	        for(int x:result)
	       System.out.print(x+" ");
	      
	        /*static boolean twosum(int[] arr, int target) {
			  for(int i=0;i<arr.length;i++) {
				  for(int j=i+1;j<arr.length; j++) {
					if(arr[i]+arr[j]==target)
						return true;
				  }
			  }
			  return false;
		  }**/
		
		    /*public static int[] twoSumTwoPointer(int[] nums, int target) {
		       
		        Arrays.sort(nums);
		        
		        
		        int st = 0;
		        int end = nums.length - 1;
		        
		        
		        while (st < end) {
		            int sum = nums[st] + nums[end];
		            
		            if (sum == target) {
		                return new int[]{nums[st], nums[end]};
		            } else if (sum < target) {
		                
		                st++;
		            } else {
		                
		                end--;
		            }
		        }
		        int[] result = twoSumTwoPointer(arr, target);
		        for(int x:result)
		       System.out.print(x+" ");
		        
		        return new int[]{};
		    }*/

	        
	    }
	}
